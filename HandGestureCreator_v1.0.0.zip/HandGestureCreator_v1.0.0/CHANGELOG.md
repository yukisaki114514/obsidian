# Changelog

## v1.0.0 (2026-11-18)
- 初回リリース
- 専用ウィンドウ (Tools > Hand Gesture Creator) で指マッスルを編集・ライブプレビュー
- 組み込みプリセット: Open / Fist / Point / Peace / ThumbsUp / RockNRoll / HandGun
- プロジェクト共通ライブラリ (JSON) への保存・読込・削除・検索
- .anim 書き出し / 読み込み、JSON 書き出し / 読み込み
- Humanoid マッスル値ベースによる他アバターへの移植
